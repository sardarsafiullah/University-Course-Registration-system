#include "Graph.h"
#include <iostream>
#include <algorithm>
using namespace std;

void PrerequisiteGraph::addCourse(string course) {
    if (adjList.find(course) == adjList.end()) {
        adjList[course] = vector<string>();
    }
}

void PrerequisiteGraph::addPrerequisite(string course, string prerequisite) {
    addCourse(course);
    addCourse(prerequisite);
    
    if (find(adjList[course].begin(), adjList[course].end(), prerequisite) == adjList[course].end()) {
        adjList[course].push_back(prerequisite);
    }
}

bool PrerequisiteGraph::checkPrerequisites(string course, vector<string> completedCourses) {
    if (adjList.find(course) == adjList.end()) return true;
    
    for (const string& prereq : adjList[course]) {
        bool found = false;
        for (const string& completed : completedCourses) {
            if (completed == prereq) {
                found = true;
                break;
            }
        }
        if (!found) return false;
    }
    return true;
}

void PrerequisiteGraph::displayGraph() {
    cout << "\n=== Course Prerequisite Graph ===" << endl;
    for (const auto& entry : adjList) {
        cout << entry.first << " -> ";
        for (const string& prereq : entry.second) {
            cout << prereq << " ";
        }
        cout << endl;
    }
}