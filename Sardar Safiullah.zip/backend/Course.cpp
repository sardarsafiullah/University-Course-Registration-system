#include "Course.h"
#include <iostream>
using namespace std;

Course::Course(string code, string name, int cred, int capacity)
    : courseCode(code), courseName(name), credits(cred), 
      maxCapacity(capacity), currentEnrollment(0) {}

bool Course::enrollStudent(string studentID) {
    if (isFull()) {
        cout << courseCode << " is full. Adding to waitlist." << endl;
        return addToWaitlist(studentID);
    }
    
    currentEnrollment++;
    cout << studentID << " enrolled in " << courseCode << endl;
    return true;
}

bool Course::dropStudent(string studentID) {
    cout << studentID << " dropped from " << courseCode << endl;
    currentEnrollment--;
    
    if (!waitlist.empty()) {
        string nextStudent = waitlist.front();
        waitlist.pop();
        currentEnrollment++;
        cout << nextStudent << " moved from waitlist to " << courseCode << endl;
    }
    
    return true;
}

bool Course::addToWaitlist(string studentID) {
    waitlist.push(studentID);
    cout << studentID << " added to waitlist for " << courseCode << endl;
    return true;
}

void Course::addPrerequisite(string prereq) {
    prerequisites.push_back(prereq);
}

void Course::displayInfo() const {
    cout << "\n=== Course Info ===" << endl;
    cout << "Code: " << courseCode << endl;
    cout << "Name: " << courseName << endl;
    cout << "Credits: " << credits << endl;
    cout << "Enrollment: " << currentEnrollment << "/" << maxCapacity << endl;
    
    if (!prerequisites.empty()) {
        cout << "Prerequisites: ";
        for (const auto& prereq : prerequisites) {
            cout << prereq << " ";
        }
        cout << endl;
    }
    
    cout << "Waitlist size: " << waitlist.size() << endl;
}