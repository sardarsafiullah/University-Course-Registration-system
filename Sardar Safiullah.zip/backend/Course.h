#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>
#include <queue>
using namespace std;

class Course {
private:
    string courseCode;
    string courseName;
    int credits;
    int maxCapacity;
    int currentEnrollment;
    vector<string> prerequisites;
    queue<string> waitlist;
    
public:
    Course(string code, string name, int cred, int capacity);
    
    string getCode() const { return courseCode; }
    string getName() const { return courseName; }
    int getCredits() const { return credits; }
    int getCapacity() const { return maxCapacity; }
    int getEnrollment() const { return currentEnrollment; }
    vector<string> getPrerequisites() const { return prerequisites; }
    
    bool enrollStudent(string studentID);
    bool dropStudent(string studentID);
    bool addToWaitlist(string studentID);
    bool isFull() const { return currentEnrollment >= maxCapacity; }
    
    void addPrerequisite(string prereq);
    
    void displayInfo() const;
};

#endif