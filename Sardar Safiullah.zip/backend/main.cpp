#include <iostream>
#include "Student.h"
#include "Course.h"
#include "Graph.h"
#include <stack>
#include <queue>
#include <map>
using namespace std;

int main() {
    cout << "==========================================" << endl;
    cout << "  UNIVERSITY COURSE REGISTRATION SYSTEM  " << endl;
    cout << "      Data Structures & Algorithms       " << endl;
    cout << "==========================================" << endl;
    
    cout << "\n=== DEMONSTRATING DSA CONCEPTS ===\n" << endl;
    
    // 1. GRAPH - Course Prerequisites
    cout << "1. GRAPH: Course Prerequisites" << endl;
    cout << "-----------------------------" << endl;
    PrerequisiteGraph graph;
    graph.addPrerequisite("CS201", "CS101");
    graph.addPrerequisite("CS301", "CS201");
    graph.addPrerequisite("CS301", "MATH101");
    graph.displayGraph();
    
    // Check prerequisites
    vector<string> completed = {"CS101", "MATH101"};
    cout << "\nCompleted courses: CS101, MATH101" << endl;
    cout << "Can take CS201? " << (graph.checkPrerequisites("CS201", completed) ? "YES" : "NO") << endl;
    cout << "Can take CS301? " << (graph.checkPrerequisites("CS301", completed) ? "YES" : "NO") << endl;
    
    // 2. LINKED LIST (in Student class vector)
    cout << "\n\n2. LINKED LIST CONCEPT: Student Course List" << endl;
    cout << "------------------------------------------" << endl;
    Student student1("S001", "Ali Ahmed");
    student1.registerCourse("CS101", 3);
    student1.registerCourse("MATH101", 4);
    student1.displayInfo();
    
    // 3. QUEUE - Waitlist System
    cout << "\n\n3. QUEUE: Course Waitlist" << endl;
    cout << "------------------------" << endl;
    Course cs201("CS201", "Data Structures", 3, 2); // Capacity: 2
    
    cs201.enrollStudent("S001");
    cs201.enrollStudent("S002");
    cs201.enrollStudent("S003"); // Should go to waitlist
    cs201.enrollStudent("S004"); // Should go to waitlist
    
    cout << "\nAfter enrollments:" << endl;
    cs201.displayInfo();
    
    // Simulate a drop
    cout << "\nWhen S001 drops CS201:" << endl;
    cs201.dropStudent("S001");
    cs201.displayInfo();
    
    // 4. STACK - Undo Operation
    cout << "\n\n4. STACK: Undo Registration" << endl;
    cout << "--------------------------" << endl;
    stack<pair<string, string>> undoStack; // studentID, courseCode
    
    student1.registerCourse("ENG101", 3);
    undoStack.push({"S001", "ENG101"});
    cout << "Registered for ENG101 (added to undo stack)" << endl;
    
    student1.registerCourse("PHY101", 3);
    undoStack.push({"S001", "PHY101"});
    cout << "Registered for PHY101 (added to undo stack)" << endl;
    
    cout << "\nBefore undo:" << endl;
    student1.displayInfo();
    
    // Undo last registration
    if (!undoStack.empty()) {
        auto last = undoStack.top();
        undoStack.pop();
        student1.dropCourse(last.second, 3);
        cout << "\nUndid registration of " << last.second << endl;
    }
    
    cout << "\nAfter undo:" << endl;
    student1.displayInfo();
    
    // 5. HASH TABLE CONCEPT (using map)
    cout << "\n\n5. HASH TABLE CONCEPT: Student Directory" << endl;
    cout << "---------------------------------------" << endl;
    map<string, Student*> studentDirectory; // Simulating hash table
    
    Student* s2 = new Student("S002", "Sara Khan");
    Student* s3 = new Student("S003", "Bilal Ahmed");
    
    studentDirectory["S002"] = s2;
    studentDirectory["S003"] = s3;
    
    cout << "Student Directory (Map as Hash Table):" << endl;
    for (const auto& entry : studentDirectory) {
        cout << "Key: " << entry.first << " -> Student: " << entry.second->getName() << endl;
    }
    
    // Search in O(1) average time
    string searchID = "S002";
    if (studentDirectory.find(searchID) != studentDirectory.end()) {
        cout << "\nFound student " << searchID << ": " << studentDirectory[searchID]->getName() << endl;
    }
    
    // 6. BINARY SEARCH TREE CONCEPT (sorted course catalog)
    cout << "\n\n6. BINARY SEARCH TREE CONCEPT: Sorted Courses" << endl;
    cout << "---------------------------------------------" << endl;
    map<string, Course*> courseCatalog; // BST-like sorted structure
    
    Course* c1 = new Course("CS101", "Intro to CS", 3, 50);
    Course* c2 = new Course("BIO101", "Biology", 4, 45);
    Course* c3 = new Course("MATH101", "Calculus", 4, 60);
    Course* c4 = new Course("ENG101", "English", 3, 40);
    
    courseCatalog["CS101"] = c1;
    courseCatalog["BIO101"] = c2;
    courseCatalog["MATH101"] = c3;
    courseCatalog["ENG101"] = c4;
    
    cout << "Courses sorted by code (like BST inorder traversal):" << endl;
    for (const auto& entry : courseCatalog) {
        cout << entry.first << " - " << entry.second->getName() << endl;
    }
    
    // Cleanup
    delete s2;
    delete s3;
    delete c1;
    delete c2;
    delete c3;
    delete c4;
    
    cout << "\n==========================================" << endl;
    cout << "         DEMONSTRATION COMPLETE          " << endl;
    cout << "==========================================" << endl;
    
    return 0;
}