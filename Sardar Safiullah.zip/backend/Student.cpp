#include "Student.h"
#include <iostream>
#include <algorithm>
using namespace std;

Student::Student(string id, string n, int maxCred) 
    : studentID(id), name(n), maxCredits(maxCred), currentCredits(0) {}

bool Student::registerCourse(string courseCode, int courseCredits) {
    if (isRegistered(courseCode)) {
        cout << "Already registered for " << courseCode << endl;
        return false;
    }
    
    if (currentCredits + courseCredits > maxCredits) {
        cout << "Credit limit exceeded!" << endl;
        return false;
    }
    
    registeredCourses.push_back(courseCode);
    currentCredits += courseCredits;
    cout << "Registered for " << courseCode << endl;
    return true;
}

bool Student::dropCourse(string courseCode, int courseCredits) {
    auto it = find(registeredCourses.begin(), registeredCourses.end(), courseCode);
    
    if (it != registeredCourses.end()) {
        registeredCourses.erase(it);
        currentCredits -= courseCredits;
        cout << "Dropped " << courseCode << endl;
        return true;
    }
    
    cout << "Not registered for " << courseCode << endl;
    return false;
}

bool Student::isRegistered(string courseCode) const {
    return find(registeredCourses.begin(), registeredCourses.end(), courseCode) != registeredCourses.end();
}

void Student::displayInfo() const {
    cout << "\n=== Student Info ===" << endl;
    cout << "ID: " << studentID << endl;
    cout << "Name: " << name << endl;
    cout << "Credits: " << currentCredits << "/" << maxCredits << endl;
    cout << "Courses: ";
    for (const auto& course : registeredCourses) {
        cout << course << " ";
    }
    cout << endl;
}