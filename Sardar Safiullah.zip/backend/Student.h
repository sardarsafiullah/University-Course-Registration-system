#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <vector>
using namespace std;

class Student {
private:
    string studentID;
    string name;
    vector<string> registeredCourses;
    int maxCredits;
    int currentCredits;
    
public:
    Student(string id, string n, int maxCred = 18);
    
    string getID() const { return studentID; }
    string getName() const { return name; }
    int getCurrentCredits() const { return currentCredits; }
    vector<string> getRegisteredCourses() const { return registeredCourses; }
    
    bool registerCourse(string courseCode, int courseCredits);
    bool dropCourse(string courseCode, int courseCredits);
    bool isRegistered(string courseCode) const;
    
    void displayInfo() const;
};

#endif