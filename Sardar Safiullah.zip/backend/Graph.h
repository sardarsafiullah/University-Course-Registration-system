#ifndef GRAPH_H
#define GRAPH_H

#include <map>
#include <vector>
#include <string>
using namespace std;

class PrerequisiteGraph {
private:
    map<string, vector<string>> adjList;
    
public:
    void addCourse(string course);
    void addPrerequisite(string course, string prerequisite);
    bool checkPrerequisites(string course, vector<string> completedCourses);
    void displayGraph();
};

#endif