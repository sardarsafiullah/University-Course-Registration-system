// Global Variables
// BACKEND CONNECTION
async function connectToBackend() {
    try {
        // Try to load data from C++ backend JSON file
        const response = await fetch('../backend/data.json');
        if (response.ok) {
            const backendData = await response.json();
            console.log('Connected to C++ Backend Successfully!', backendData);
            
            // Update courses with real data from backend
            if (backendData.courses && backendData.courses.length > 0) {
                allCourses = backendData.courses;
                loadCourses();
                populateCourseSelect();
                
                // Show connection status
                document.getElementById('connectionStatus').innerHTML = 
                    '<span class="badge bg-success">Connected to C++ Backend</span>';
            }
            
            showNotification('✅ Connected to C++ Backend with real data!', 'success');
            return true;
        }
    } catch (error) {
        console.log('Using sample data. Backend connection:', error.message);
        document.getElementById('connectionStatus').innerHTML = 
            '<span class="badge bg-warning">Using Sample Data</span>';
    }
    return false;
}

// Add connection status to HTML
function addConnectionStatus() {
    const nav = document.querySelector('.navbar-nav');
    const statusItem = document.createElement('li');
    statusItem.className = 'nav-item';
    statusItem.id = 'connectionStatus';
    statusItem.innerHTML = '<span class="badge bg-secondary">Connecting...</span>';
    nav.appendChild(statusItem);
}
let currentStudent = null;
let allCourses = [];
let registeredCourses = [];

// Sample Data (In real project, this comes from C++ backend via JSON)
const sampleCourses = [
    { code: "CS101", name: "Introduction to Computer Science", dept: "CS", credits: 3, capacity: 50, enrolled: 45, prerequisites: [] },
    { code: "CS201", name: "Data Structures", dept: "CS", credits: 3, capacity: 40, enrolled: 38, prerequisites: ["CS101"] },
    { code: "CS301", name: "Algorithms", dept: "CS", credits: 3, capacity: 30, enrolled: 28, prerequisites: ["CS201"] },
    { code: "MATH101", name: "Calculus I", dept: "MATH", credits: 4, capacity: 60, enrolled: 55, prerequisites: [] },
    { code: "MATH201", name: "Linear Algebra", dept: "MATH", credits: 3, capacity: 45, enrolled: 40, prerequisites: ["MATH101"] },
    { code: "ENG101", name: "Introduction to Engineering", dept: "ENG", credits: 3, capacity: 50, enrolled: 48, prerequisites: [] },
    { code: "CS401", name: "Database Systems", dept: "CS", credits: 3, capacity: 35, enrolled: 30, prerequisites: ["CS201"] },
    { code: "CS501", name: "Artificial Intelligence", dept: "CS", credits: 3, capacity: 30, enrolled: 25, prerequisites: ["CS301", "MATH201"] }
];

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    addConnectionStatus();
    connectToBackend().then(() => {
        // After connecting to backend, load courses
        loadCourses();
        populateCourseSelect();
        simulateBackendConnection();
    });
});

// Load courses into the UI
function loadCourses() {
    allCourses = sampleCourses;
    const container = document.getElementById('coursesContainer');
    container.innerHTML = '';
    
    allCourses.forEach(course => {
        const enrolledPercent = (course.enrolled / course.capacity) * 100;
        const card = document.createElement('div');
        card.className = 'col-md-6 col-lg-4 fade-in';
        card.innerHTML = `
            <div class="card course-card">
                <div class="card-header bg-${course.dept.toLowerCase()} text-white d-flex justify-content-between">
                    <span>${course.code}</span>
                    <span class="badge bg-light text-dark">${course.credits} Credits</span>
                </div>
                <div class="card-body">
                    <h5 class="card-title">${course.name}</h5>
                    <p class="card-text">
                        <i class="fas fa-building"></i> ${course.dept} Department<br>
                        <i class="fas fa-users"></i> ${course.enrolled}/${course.capacity} enrolled
                    </p>
                    <div class="progress">
                        <div class="progress-bar ${enrolledPercent > 90 ? 'bg-danger' : enrolledPercent > 75 ? 'bg-warning' : 'bg-success'}" 
                             style="width: ${enrolledPercent}%"></div>
                    </div>
                    ${course.prerequisites.length > 0 ? 
                        `<p class="mt-2"><small><i class="fas fa-sitemap"></i> Prereqs: ${course.prerequisites.join(', ')}</small></p>` : 
                        ''}
                    <button class="btn btn-sm btn-outline-primary mt-2" onclick="showCourseDetails('${course.code}')">
                        <i class="fas fa-info-circle"></i> Details
                    </button>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}

// Populate course select dropdown
function populateCourseSelect() {
    const select = document.getElementById('courseSelect');
    select.innerHTML = '<option value="">Select a course...</option>';
    
    allCourses.forEach(course => {
        const option = document.createElement('option');
        option.value = course.code;
        option.textContent = `${course.code} - ${course.name}`;
        select.appendChild(option);
    });
    
    // Add change event listener
    select.addEventListener('change', function() {
        checkPrerequisites(this.value);
    });
}

// Check prerequisites for selected course
function checkPrerequisites(courseCode) {
    const prereqDiv = document.getElementById('prereqCheck');
    const course = allCourses.find(c => c.code === courseCode);
    
    if (!course) {
        prereqDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Please select a course';
        prereqDiv.className = 'alert alert-warning';
        return;
    }
    
    if (course.prerequisites.length === 0) {
        prereqDiv.innerHTML = '<i class="fas fa-check-circle"></i> No prerequisites required';
        prereqDiv.className = 'alert alert-success';
    } else {
        // Check if student has completed prerequisites
        const missingPrereqs = course.prerequisites.filter(prereq => 
            !registeredCourses.includes(prereq)
        );
        
        if (missingPrereqs.length === 0) {
            prereqDiv.innerHTML = `<i class="fas fa-check-circle"></i> All prerequisites satisfied: ${course.prerequisites.join(', ')}`;
            prereqDiv.className = 'alert alert-success';
        } else {
            prereqDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> Missing prerequisites: ${missingPrereqs.join(', ')}`;
            prereqDiv.className = 'alert alert-danger';
        }
    }
}

// Register for a course
function registerCourse() {
    const courseSelect = document.getElementById('courseSelect');
    const courseCode = courseSelect.value;
    const studentId = document.getElementById('studentId').value;
    
    if (!studentId) {
        alert('Please enter your Student ID first');
        return;
    }
    
    if (!courseCode) {
        alert('Please select a course to register');
        return;
    }
    
    const course = allCourses.find(c => c.code === courseCode);
    
    // Check capacity
    if (course.enrolled >= course.capacity) {
        alert(`Course ${courseCode} is full! You can join the waitlist.`);
        return;
    }
    
    // Check prerequisites
    const missingPrereqs = course.prerequisites.filter(prereq => 
        !registeredCourses.includes(prereq)
    );
    
    if (missingPrereqs.length > 0) {
        alert(`Cannot register. Missing prerequisites: ${missingPrereqs.join(', ')}`);
        return;
    }
    
    // Register course
    registeredCourses.push(courseCode);
    course.enrolled++;
    
    // Update UI
    updateRegisteredCoursesList();
    loadCourses(); // Refresh course list
    populateCourseSelect();
    
    // Show success message
    showNotification(`Successfully registered for ${courseCode}`, 'success');
    
    // Log to console (simulating backend call)
    console.log(`Student ${studentId} registered for ${courseCode}`);
}

// Drop a course
function dropSelectedCourse() {
    const courseSelect = document.getElementById('courseSelect');
    const courseCode = courseSelect.value;
    const studentId = document.getElementById('studentId').value;
    
    if (!studentId) {
        alert('Please enter your Student ID first');
        return;
    }
    
    if (!courseCode) {
        alert('Please select a course to drop');
        return;
    }
    
    const index = registeredCourses.indexOf(courseCode);
    if (index === -1) {
        alert(`You are not registered for ${courseCode}`);
        return;
    }
    
    // Drop course
    registeredCourses.splice(index, 1);
    const course = allCourses.find(c => c.code === courseCode);
    if (course) course.enrolled--;
    
    // Update UI
    updateRegisteredCoursesList();
    loadCourses(); // Refresh course list
    populateCourseSelect();
    
    // Show success message
    showNotification(`Successfully dropped ${courseCode}`, 'info');
    
    // Log to console (simulating backend call)
    console.log(`Student ${studentId} dropped ${courseCode}`);
}

// Update registered courses list
function updateRegisteredCoursesList() {
    const list = document.getElementById('registeredCourses');
    list.innerHTML = '';
    
    if (registeredCourses.length === 0) {
        list.innerHTML = '<li class="list-group-item text-muted">No courses registered</li>';
        return;
    }
    
    registeredCourses.forEach(courseCode => {
        const course = allCourses.find(c => c.code === courseCode);
        if (course) {
            const li = document.createElement('li');
            li.className = 'list-group-item';
            li.innerHTML = `
                <div>
                    <strong>${course.code}</strong><br>
                    <small>${course.name}</small>
                </div>
                <span class="badge bg-primary">${course.credits} credits</span>
            `;
            list.appendChild(li);
        }
    });
}

// Load student's registered courses
function loadStudentCourses() {
    const studentId = document.getElementById('studentId').value;
    
    if (!studentId) {
        alert('Please enter your Student ID');
        return;
    }
    
    // Simulate loading from backend
    showNotification(`Loading courses for student ${studentId}...`, 'info');
    
    // In real app, this would be an API call to C++ backend
    setTimeout(() => {
        // For demo, load some random courses
        registeredCourses = ['CS101', 'MATH101']; // Sample registered courses
        
        updateRegisteredCoursesList();
        showNotification(`Loaded ${registeredCourses.length} courses for ${studentId}`, 'success');
    }, 1000);
}

// Search courses
function searchCourses() {
    const searchTerm = document.getElementById('searchCourse').value.toLowerCase();
    const cards = document.querySelectorAll('.course-card');
    
    cards.forEach(card => {
        const courseCode = card.querySelector('.card-header span').textContent.toLowerCase();
        const courseName = card.querySelector('.card-title').textContent.toLowerCase();
        
        if (courseCode.includes(searchTerm) || courseName.includes(searchTerm)) {
            card.parentElement.style.display = 'block';
        } else {
            card.parentElement.style.display = 'none';
        }
    });
}

// Filter courses by department
function filterCourses() {
    const dept = document.getElementById('filterDept').value;
    const cards = document.querySelectorAll('.course-card');
    
    cards.forEach(card => {
        const cardDept = card.querySelector('.card-text').textContent;
        if (!dept || cardDept.includes(dept)) {
            card.parentElement.style.display = 'block';
        } else {
            card.parentElement.style.display = 'none';
        }
    });
}

// Show course details
function showCourseDetails(courseCode) {
    const course = allCourses.find(c => c.code === courseCode);
    if (course) {
        alert(`${course.code}: ${course.name}\n\nDepartment: ${course.dept}\nCredits: ${course.credits}\nEnrolled: ${course.enrolled}/${course.capacity}\nPrerequisites: ${course.prerequisites.join(', ') || 'None'}`);
    }
}

// Modal functions
function openLoginModal() {
    const modal = new bootstrap.Modal(document.getElementById('loginModal'));
    modal.show();
}

function performLogin() {
    const userType = document.getElementById('userType').value;
    const username = document.getElementById('loginUsername').value;
    
    if (!username) {
        alert('Please enter username');
        return;
    }
    
    if (userType === 'student') {
        document.getElementById('studentId').value = username;
        showNotification(`Logged in as student: ${username}`, 'success');
    } else {
        showNotification(`Logged in as admin: ${username}`, 'success');
        // Admin features would be enabled here
    }
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
    modal.hide();
}

// Utility function to show notifications
function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Scroll to section
function scrollToSection(sectionId) {
    document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
}

// Simulate backend connection
function simulateBackendConnection() {
    console.log('Simulating C++ backend connection...');
    console.log('Graph: Tracking course prerequisites');
    console.log('BST: Organizing course catalog');
    console.log('Hash Table: Managing student data');
    console.log('Stack: Handling undo/redo operations');
    console.log('Queue: Managing course waitlists');
}

// Export data function (for backend)
function exportToBackend() {
    const data = {
        courses: allCourses,
        registrations: registeredCourses.map(code => ({
            studentId: document.getElementById('studentId').value || 'S001',
            courseCode: code,
            timestamp: new Date().toISOString()
        }))
    };
    
    console.log('Data for C++ backend:', JSON.stringify(data, null, 2));
    showNotification('Data exported to C++ backend', 'info');
}